"""Show the public layouts, first switch contact and stove goal on the full post-drawer clock."""
import argparse
from contextlib import nullcontext
from io import BytesIO
import json
from pathlib import Path
import zipfile

import matplotlib
matplotlib.use('Agg')
from matplotlib.lines import Line2D
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import numpy as np
from PIL import Image


def plot(folder, output):
    bundle=folder/'study.zip'
    with (zipfile.ZipFile(bundle) if bundle.is_file() else nullcontext()) as z:
        def payload(name):
            return z.read(name) if z else (folder/name).read_bytes()
        def read(name):
            return json.loads(payload(name))
        design=read('design.json')
        gates=read('gate.json')
        runs=read('sessions.json')
        fig,axes=plt.subplots(len(design['layouts']),3,figsize=(12.2,5.45),layout='constrained',squeeze=False,
                              gridspec_kw={'width_ratios':[.8,1.3,1.3]})
        styles={'immediate':('Immediate','#515F70','-.'),'wait':('Hold posture','#B1530B','--'),
                'pose':('Return to common posture','#006F70','-')}
        hz=design['control_hz']
        end=design['budgets'][-1]
        for i,layout in enumerate(design['layouts']):
            group=gates[str(layout)]
            image_source=next(n for n,t in group['trials'].items() if t['task']=='drawer' and t['block']==1 and t['key']==0)
            signature=read('gates/'+image_source+'.json')['queries'][0]['live']['observation/image']
            axes[i,0].imshow(Image.open(BytesIO(payload('frames/'+signature+'.png'))))
            axes[i,0].set(xticks=[],yticks=[],ylabel=f'Layout {layout}')
            for spine in axes[i,0].spines.values():
                spine.set_visible(False)
            for mode in design['modes']:
                contacts,on=[],[]
                for name,e in runs.items():
                    if e['layout']!=layout or e['mode']!=mode:
                        continue
                    pre=read(f"preparation/{e['arm']}-{mode}-{e['lead']}.json")
                    path=read('paths/'+name+'.json')
                    rows=[pre['start']['stove'],*[r['stove'] for r in pre['rows']],*path['rows']]
                    assert len(rows)==end+1
                    contacts.append(np.maximum.accumulate([r['button_contact'] for r in rows]))
                    on.append([r['on'] for r in rows])
                label,color,ls=styles[mode]
                for axis,values in zip(axes[i,1:],(contacts,on)):
                    if values:
                        axis.step(np.arange(end+1)/hz,np.mean(values,axis=0),where='post',color=color,ls=ls,lw=2)
            for axis in axes[i,1:]:
                for tick in (design['lead'],design['budgets'][0]):
                    axis.axvline(tick/hz,color='#9ba4ad',ls=':',lw=.85)
                axis.set(xlim=(0,end/hz),ylim=(-.025,1.035),xticks=[0,3,5,8,10,12,15],yticks=[0,.25,.5,.75,1])
                axis.yaxis.set_major_formatter(PercentFormatter(1,decimals=0))
                axis.spines[['top','right']].set_visible(False)
                axis.grid(axis='y',color='#dce1e4',lw=.65)
                if not group['donors']:
                    axis.text(.5,.5,'No eligible drawer endpoint',transform=axis.transAxes,ha='center')
        for axis,title in zip(axes[0],('Public start','Touched moving switch','Stove on')):
            axis.set_title(title,loc='left')
        for axis in axes[-1,1:]:
            axis.set_xlabel('Seconds since the drawer endpoint')
        fig.legend(handles=[Line2D([],[],label=v[0],color=v[1],ls=v[2],lw=2) for v in styles.values()],
                   loc='outside lower center',ncol=3,frameon=False)
        fig.savefig(output,dpi=180,bbox_inches='tight')
        plt.close(fig)


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('folder',type=Path)
    ap.add_argument('output',type=Path)
    a=ap.parse_args()
    plot(a.folder,a.output)
