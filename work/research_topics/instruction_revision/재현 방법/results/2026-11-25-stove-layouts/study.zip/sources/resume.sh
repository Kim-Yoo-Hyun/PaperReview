#!/bin/sh
# Local Docker only. No host Python, dependency installation, or emulation.
set -eu
recipe_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
task=instruction-revision-p0
image=paper-revision-p0:7329c159
base=ghcr.io/astral-sh/uv:0.8.22-python3.11-bookworm-slim@sha256:e59dc06793821e707e3a90234025c996eb4db2af807fdd7d9dd731d2fc678a96
data_volume=paper-revision-p0-data
run_volume=paper-revision-p0-runs
mode=${1:-help}
case "$mode" in
  help|-h|--help)
    printf '%s\n' 'Local Docker stages: check → gpu → build → assets → smoke → atomic <new output directory>' \
      'R1: r1 <new output directory>, verify-r1 <run directory>, replay-r1 <run directory>' \
      'R1 actual partial update: raw-update <new output directory>, verify-raw-update <run directory>, replay-r1 <run directory>' \
      'Held-out R1 layouts: layouts <new directory>, verify-layouts <run or archive>, replay-layouts <run or archive>' \
      'Neutral B/T on the sealed layouts: neutral-layouts <new directory>, verify-neutral-layouts <run or archive>, replay-layouts <run or archive>' \
      'Bottle position crossover: bottle-xy <new directory>, verify-bottle-xy <run or archive>, replay-layouts <run or archive>' \
      'Individual cameras and robustness: camera-core <new directory>, camera-expand <core directory>, camera-repeat <expanded directory>, verify-cameras <run or archive>, replay-cameras <run or archive>' \
      'Independent LIBERO drawer: drawer <new directory>, verify-drawer <run or archive>, replay-drawer <run or archive>' \
      'Drawer-to-stove continuation: stove <new directory>, verify-stove <run or archive>, replay-stove <run or archive>' \
      'Common arm posture before stove: stove-pose <new directory>, verify-stove-pose <run or archive>, replay-stove-pose <run or archive> [new report file]' \
      'Held-out drawer layouts: stove-layouts <new directory>, verify-stove-layouts <run or archive>, replay-stove-layouts <run or archive> [new report file]' \
      'Natural frame recapture: drawer-recapture <primary run or archive> <new directory>; drawer-pairs <primary run or archive> <recapture directory>' \
      'First revised camera inputs: first-view <new directory>, verify-first-view <run or archive>, replay-layouts <run or archive>' \
      'Fixed commands on both bottle positions: command-cross <new directory>, verify-command-cross <completed directory>' \
      'Matched R1 clauses: mention <new output directory>, verify-mention <run directory>, replay-r1 <run directory>' \
      'Compare independent matched batches: verify-mention <first run directory> <second run directory>' \
      'Post-placement language swap: post-release <new output directory>, verify-post-release <run directory>, replay-r1 <run directory>' \
      'R4 bottle-to-rack comparison: r4 <new output directory>, verify-r4 <run directory>, replay-r4 <run directory>' \
      'Original two-clause batch with a newly inferred prefix: mention-initial <new output directory>' \
      'Verify archived or freshly recorded R8 paths: verify <run directory>' \
      'Use: sh "work/research_topics/instruction_revision/재현 방법/resume.sh" <stage>' \
      'Optional: REVISION_GPU_DEVICE=<one numeric GPU index, default 0>' \
      'Build/assets download into Docker only; smoke is one bounded native IO probe.'
    exit 0 ;;
  check|gpu|build|assets|smoke|results|atomic|verify|r1|verify-r1|replay-r1|mention|mention-initial|verify-mention|post-release|verify-post-release|layouts|verify-layouts|replay-layouts|neutral-layouts|verify-neutral-layouts|bottle-xy|verify-bottle-xy|first-view|verify-first-view|stove|verify-stove|replay-stove|stove-pose|verify-stove-pose|replay-stove-pose|stove-layouts|verify-stove-layouts|replay-stove-layouts|drawer|drawer-recapture|drawer-pairs|verify-drawer|replay-drawer|camera-core|camera-expand|camera-repeat|verify-cameras|replay-cameras|command-cross|verify-command-cross|raw-update|verify-raw-update|r4|verify-r4|replay-r4) ;;
  *) printf 'Unknown stage: %s\n' "$mode" >&2; exit 2 ;;
esac

if [ -n "${DOCKER_CONTEXT:-}" ]; then
  endpoint=$(docker context inspect "$DOCKER_CONTEXT" --format '{{.Endpoints.docker.Host}}')
elif [ -n "${DOCKER_HOST:-}" ]; then
  endpoint=$DOCKER_HOST
else
  endpoint=$(docker context inspect "$(docker context show)" --format '{{.Endpoints.docker.Host}}')
fi
case "$endpoint" in
  unix://*|npipe://*) ;;
  *) printf 'Only the selected local Docker endpoint is allowed: %s\n' "$endpoint" >&2; exit 3 ;;
esac
d() (unset DOCKER_CONTEXT DOCKER_HOST; docker --host "$endpoint" "$@")
platform=$(d version --format '{{.Server.Os}}/{{.Server.Arch}}')
printf 'Local endpoint: %s; daemon: %s\n' "$endpoint" "$platform" >&2
d info --format 'cpus={{.NCPU}} memory_bytes={{.MemTotal}} runtimes={{range $name, $_ := .Runtimes}}{{$name}} {{end}}' >&2
if [ "$platform" != linux/amd64 ]; then
  printf 'NOT_MET: linux/amd64 with NVIDIA CUDA/EGL is required; no emulation or fallback.\n' >&2
  exit 3
fi
[ "$mode" != check ] || exit 0

gpu_device=${REVISION_GPU_DEVICE:-0}
case "$gpu_device" in ''|*[!0-9]*) printf 'Select one numeric GPU index.\n' >&2; exit 2 ;; esac
container=paper-revision-p0-"$mode"-$$
cleanup() {
  owned=$(d inspect --format '{{index .Config.Labels "paperreview.task"}}' "$container" 2>/dev/null || true)
  if [ "$owned" = "$task" ]; then d rm -f "$container" >/dev/null; fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

gpu() {
  d image inspect "$base" >/dev/null 2>&1 || d pull --platform linux/amd64 "$base"
  d run --rm --pull never --name "$container" --label "paperreview.task=$task" \
    --network none --gpus "device=$gpu_device" \
    --env NVIDIA_DRIVER_CAPABILITIES=compute,graphics,utility \
    --entrypoint nvidia-smi "$base" \
    --query-gpu=name,uuid,driver_version,memory.total --format=csv,noheader
}
if [ "$mode" = gpu ]; then gpu; exit 0; fi
if [ "$mode" = build ]; then
  gpu
  if d image inspect "$image" >/dev/null 2>&1; then
    [ "$(d image inspect --format '{{index .Config.Labels "paperreview.task"}}' "$image")" = "$task" ] || {
      printf 'Existing image tag belongs to another task; refusing replacement.\n' >&2; exit 4;
    }
  fi
  d build --platform linux/amd64 --tag "$image" "$recipe_dir"
  d image inspect --format 'built_image={{.Id}} platform={{.Os}}/{{.Architecture}}' "$image"
  exit 0
fi

image_id=$(d image inspect --format '{{.Id}}' "$image")
[ "$(d image inspect --format '{{index .Config.Labels "paperreview.task"}}' "$image_id")" = "$task" ] || exit 4
[ "$(d image inspect --format '{{.Os}}/{{.Architecture}}' "$image_id")" = linux/amd64 ] || exit 4
if [ "$mode" = drawer-recapture ] || [ "$mode" = drawer-pairs ]; then
  [ "$#" -eq 3 ] && [ -d "$2" ] || { printf 'Supply the primary run and a recapture directory.\n' >&2; exit 2; }
  donor=$(CDPATH= cd -- "$2" && pwd)
  parent=$(CDPATH= cd -- "$(dirname -- "$3")" && pwd)
  leaf=$(basename -- "$3")
  if [ "$mode" = drawer-recapture ]; then
    [ ! -e "$3" ] || { printf 'Supply a new recapture directory.\n' >&2; exit 2; }
    for batch in 1 2 3 4 5 6 7 8; do
      d run --rm --pull never --name "$container" --label "paperreview.task=$task" --network none \
        --gpus "device=$gpu_device" --shm-size 2g --env CUDA_VISIBLE_DEVICES=0 --env MUJOCO_EGL_DEVICE_ID=0 \
        --env "REVISION_IMAGE_ID=$image_id" --mount "type=bind,src=$recipe_dir,dst=/packet,readonly" \
        --mount "type=bind,src=$donor,dst=/trial,readonly" --mount "type=bind,src=$parent,dst=/output" \
        --entrypoint /opt/resteer/.venv/bin/python "$image_id" /packet/drawer_recapture.py /trial "/output/$leaf" --batch "$batch"
    done
  else
    [ -f "$3/batch-8.json" ] && [ ! -e "$3/verification.json" ] || { printf 'Supply a completed raw recapture.\n' >&2; exit 2; }
    [ "$(d volume inspect --format '{{index .Labels "paperreview.task"}}' "$data_volume")" = "$task" ] || exit 4
    d run --rm --pull never --name "$container" --label "paperreview.task=$task" --network none --hostname localhost \
      --gpus "device=$gpu_device" --shm-size 2g --env CUDA_VISIBLE_DEVICES=0 --env MUJOCO_EGL_DEVICE_ID=0 \
      --env "REVISION_IMAGE_ID=$image_id" --env JAX_COMPILATION_CACHE_DIR=/tmp/revision-jit \
      --mount "type=volume,src=$data_volume,dst=/data,readonly" --mount "type=bind,src=$recipe_dir,dst=/packet,readonly" \
      --mount "type=bind,src=$donor,dst=/trial,readonly" --mount "type=bind,src=$parent,dst=/output" \
      --entrypoint /opt/resteer/third_party/openpi/.venv/bin/python "$image_id" /packet/drawer_pairs.py /trial "/output/$leaf"
  fi
  exit 0
fi
if [ "$mode" = command-cross ]; then
  [ "$#" -eq 2 ] && [ ! -e "$2" ] || { printf 'Supply a new output directory.\n' >&2; exit 2; }
  parent=$(CDPATH= cd -- "$(dirname -- "$2")" && pwd)
  leaf=$(basename -- "$2")
  for batch in first second; do
    d run --rm --pull never --name "$container" --label "paperreview.task=$task" --network none \
      --gpus "device=$gpu_device" --shm-size 2g --env CUDA_VISIBLE_DEVICES=0 --env MUJOCO_EGL_DEVICE_ID=0 \
      --env "REVISION_IMAGE_ID=$image_id" --mount "type=bind,src=$recipe_dir,dst=/packet,readonly" \
      --mount "type=bind,src=$parent,dst=/output" --entrypoint /opt/resteer/.venv/bin/python \
      "$image_id" /packet/command_cross.py "$batch" "/output/$leaf"
  done
  exit 0
fi
if [ "$mode" = replay-r1 ] || [ "$mode" = replay-r4 ] || [ "$mode" = replay-layouts ] || [ "$mode" = replay-cameras ] || [ "$mode" = replay-drawer ] || [ "$mode" = replay-stove ] || [ "$mode" = replay-stove-pose ] || [ "$mode" = replay-stove-layouts ]; then
  pose_verifier=verify_stove_pose.py
  [ "$mode" != replay-stove-layouts ] || pose_verifier=verify_stove_layouts.py
  if { [ "$mode" = replay-stove-pose ] || [ "$mode" = replay-stove-layouts ]; } && [ "$#" -eq 3 ]; then
    [ -d "$2" ] && [ ! -e "$3" ] || { printf 'Supply the run and a new report file.\n' >&2; exit 2; }
    run_path=$(CDPATH= cd -- "$2" && pwd)
    report_dir=$(CDPATH= cd -- "$(dirname -- "$3")" && pwd)
    report_file=$(basename -- "$3")
    d run --rm --pull never --name "$container" --label "paperreview.task=$task" --network none \
      --gpus "device=$gpu_device" --shm-size 2g --env CUDA_VISIBLE_DEVICES=0 --env MUJOCO_EGL_DEVICE_ID=0 \
      --env OMP_NUM_THREADS=1 --env OPENBLAS_NUM_THREADS=1 \
      --mount "type=bind,src=$recipe_dir,dst=/packet,readonly" --mount "type=bind,src=$run_path,dst=/trial,readonly" \
      --mount "type=bind,src=$report_dir,dst=/report" --entrypoint /opt/resteer/.venv/bin/python \
      "$image_id" "/packet/$pose_verifier" /trial replay --output "/report/$report_file"
    exit 0
  fi
  [ "$#" -eq 2 ] && [ -d "$2" ] || { printf 'Supply an existing run directory.\n' >&2; exit 2; }
  run_path=$(CDPATH= cd -- "$2" && pwd)
  set -- /packet/replay_r1.py /trial
  [ "$mode" != replay-layouts ] || set -- /packet/verify_layouts.py /trial --replay
  [ "$mode" != replay-cameras ] || set -- /packet/verify_cameras.py /trial --replay
  [ "$mode" != replay-drawer ] || set -- /packet/verify_drawer.py /trial replay
  [ "$mode" != replay-stove ] || set -- /packet/verify_stove.py /trial replay
  [ "$mode" != replay-stove-pose ] || set -- /packet/verify_stove_pose.py /trial replay
  [ "$mode" != replay-stove-layouts ] || set -- /packet/verify_stove_layouts.py /trial replay
  d run --rm --pull never --name "$container" --label "paperreview.task=$task" --network none \
    --gpus "device=$gpu_device" --shm-size 2g --env CUDA_VISIBLE_DEVICES=0 --env MUJOCO_EGL_DEVICE_ID=0 \
    --mount "type=bind,src=$recipe_dir,dst=/packet,readonly" --mount "type=bind,src=$run_path,dst=/trial,readonly" \
    --entrypoint /opt/resteer/.venv/bin/python "$image_id" "$@"
  exit 0
fi
if [ "$mode" = verify ] || [ "$mode" = verify-r1 ] || [ "$mode" = verify-mention ] || [ "$mode" = verify-post-release ] || [ "$mode" = verify-raw-update ] || [ "$mode" = verify-r4 ] || [ "$mode" = verify-layouts ] || [ "$mode" = verify-neutral-layouts ] || [ "$mode" = verify-bottle-xy ] || [ "$mode" = verify-command-cross ] || [ "$mode" = verify-first-view ] || [ "$mode" = verify-cameras ] || [ "$mode" = verify-drawer ] || [ "$mode" = verify-stove ] || [ "$mode" = verify-stove-pose ] || [ "$mode" = verify-stove-layouts ]; then
  verifier=verify_atomic.py
  [ "$mode" != verify-r1 ] || verifier=verify_r1.py
  [ "$mode" != verify-layouts ] || verifier=verify_layouts.py
  [ "$mode" != verify-neutral-layouts ] || verifier=verify_neutral_layouts.py
  [ "$mode" != verify-bottle-xy ] || verifier=verify_bottle_xy.py
  [ "$mode" != verify-command-cross ] || verifier=verify_command_cross.py
  [ "$mode" != verify-first-view ] || verifier=verify_first_view.py
  [ "$mode" != verify-cameras ] || verifier=verify_cameras.py
  [ "$mode" != verify-drawer ] || verifier=verify_drawer.py
  [ "$mode" != verify-stove ] || verifier=verify_stove.py
  [ "$mode" != verify-stove-pose ] || verifier=verify_stove_pose.py
  [ "$mode" != verify-stove-layouts ] || verifier=verify_stove_layouts.py
  [ "$mode" != verify-raw-update ] || verifier=verify_raw_update.py
  [ "$mode" != verify-mention ] || verifier=verify_mention.py
  [ "$mode" != verify-post-release ] || verifier=verify_post_release.py
  [ "$mode" != verify-r4 ] || verifier=verify_r4.py
  if [ "$mode" = verify-mention ] && [ "$#" -eq 3 ] && [ -d "$2" ] && [ -d "$3" ]; then
    first_path=$(CDPATH= cd -- "$2" && pwd)
    second_path=$(CDPATH= cd -- "$3" && pwd)
    d run --rm --pull never --name "$container" --label "paperreview.task=$task" --network none \
      --mount "type=bind,src=$recipe_dir,dst=/packet,readonly" \
      --mount "type=bind,src=$first_path,dst=/trial,readonly" --mount "type=bind,src=$second_path,dst=/trial2,readonly" \
      --entrypoint /opt/resteer/.venv/bin/python "$image_id" /packet/verify_mention.py /trial --repeat /trial2
    exit 0
  fi
  [ "$#" -eq 2 ] && [ -d "$2" ] || { printf 'Supply an existing run directory.\n' >&2; exit 2; }
  run_path=$(CDPATH= cd -- "$2" && pwd)
  d run --rm --pull never --name "$container" --label "paperreview.task=$task" --network none \
    --cap-drop ALL --security-opt no-new-privileges \
    --mount "type=bind,src=$recipe_dir,dst=/packet,readonly" \
    --mount "type=bind,src=$run_path,dst=/trial,readonly" \
    --entrypoint /opt/resteer/.venv/bin/python "$image_id" "/packet/$verifier" /trial
  exit 0
fi
volume() {
  if ! d volume inspect "$1" >/dev/null 2>&1; then
    [ "$mode" != results ] || { printf 'No saved run volume.\n' >&2; exit 4; }
    d volume create --label "paperreview.task=$task" "$1" >/dev/null
  fi
  [ "$(d volume inspect --format '{{index .Labels "paperreview.task"}}' "$1")" = "$task" ] || {
    printf 'Volume ownership mismatch: %s\n' "$1" >&2; exit 4;
  }
}
if [ "$mode" = results ]; then
  volume "$run_volume"
  d run --rm --pull never --name "$container" --label "paperreview.task=$task" --network none \
    --mount "type=volume,src=$run_volume,dst=/runs,readonly" "$image_id" results
  exit 0
fi
volume "$data_volume"
if [ "$mode" = atomic ] || [ "$mode" = r1 ] || [ "$mode" = mention ] || [ "$mode" = mention-initial ] || [ "$mode" = post-release ] || [ "$mode" = raw-update ] || [ "$mode" = r4 ] || [ "$mode" = layouts ] || [ "$mode" = neutral-layouts ] || [ "$mode" = bottle-xy ] || [ "$mode" = first-view ] || [ "$mode" = camera-core ] || [ "$mode" = camera-expand ] || [ "$mode" = camera-repeat ] || [ "$mode" = drawer ] || [ "$mode" = stove ] || [ "$mode" = stove-pose ] || [ "$mode" = stove-layouts ]; then
  runner=run_atomic.py
  [ "$mode" = atomic ] || runner=run_r1.py
  [ "$mode" != r4 ] || runner=run_r4.py
  [ "$mode" != layouts ] || runner=run_layouts.py
  [ "$mode" != neutral-layouts ] || runner=run_neutral_layouts.py
  [ "$mode" != bottle-xy ] || runner=run_bottle_xy.py
  [ "$mode" != first-view ] || runner=run_first_view.py
  case "$mode" in stove) runner=run_stove.py ;; stove-pose) runner=run_stove_pose.py ;; stove-layouts) runner=run_stove_layouts.py ;; drawer) runner=run_drawer.py ;; camera-core|camera-expand) runner=run_camera_factorial.py ;; camera-repeat) runner=run_camera_repeat.py ;; esac
  volume "$run_volume"
  if [ "$mode" = camera-repeat ]; then
    [ "$#" -eq 2 ] && [ -f "$2/run.json" ] || { printf 'Supply a completed factorial directory.\n' >&2; exit 2; }
  elif [ "$mode" = camera-expand ]; then
    [ "$#" -eq 2 ] && [ -f "$2/core.json" ] || { printf 'Supply a completed core directory.\n' >&2; exit 2; }
  else
    [ "$#" -eq 2 ] && [ ! -e "$2" ] || { printf 'Supply a new output directory.\n' >&2; exit 2; }
  fi
  parent=$(CDPATH= cd -- "$(dirname -- "$2")" && pwd)
  leaf=$(basename -- "$2")
  set -- "/packet/$runner" "/output/$leaf"
  [ "$mode" != camera-expand ] || set -- "$@" --extend
  [ "$mode" != mention ] || set -- "$@" --protocol R1_MENTION_MATCHED.json
  [ "$mode" != raw-update ] || set -- "$@" --protocol R1_RAW_UPDATE.json
  [ "$mode" != mention-initial ] || set -- "$@" --protocol R1_MENTION.json
  [ "$mode" != post-release ] || set -- "$@" --protocol R1_POST_RELEASE.json
  d run --rm --pull never --name "$container" --label "paperreview.task=$task" \
    --network none --hostname localhost --gpus "device=$gpu_device" --shm-size 2g \
    --env CUDA_VISIBLE_DEVICES=0 --env MUJOCO_EGL_DEVICE_ID=0 \
    --env "REVISION_IMAGE_ID=$image_id" --env JAX_COMPILATION_CACHE_DIR=/tmp/revision-jit \
    --mount "type=volume,src=$data_volume,dst=/data,readonly" \
    --mount "type=volume,src=$run_volume,dst=/prior,readonly" \
    --mount "type=bind,src=$recipe_dir,dst=/packet,readonly" \
    --mount "type=bind,src=$parent,dst=/output" \
    --entrypoint /opt/resteer/third_party/openpi/.venv/bin/python \
    "$image_id" "$@"
elif [ "$mode" = assets ]; then
  d run --rm --pull never --name "$container" --label "paperreview.task=$task" \
    --mount "type=volume,src=$data_volume,dst=/data" "$image_id" assets
else
  volume "$run_volume"
  d run --rm --pull never --name "$container" --label "paperreview.task=$task" \
    --network none --hostname localhost --gpus "device=$gpu_device" --shm-size 2g \
    --env CUDA_VISIBLE_DEVICES=0 --env MUJOCO_EGL_DEVICE_ID=0 \
    --env "REVISION_IMAGE_ID=$image_id" \
    --mount "type=volume,src=$data_volume,dst=/data" \
    --mount "type=volume,src=$run_volume,dst=/runs" "$image_id" smoke
fi
