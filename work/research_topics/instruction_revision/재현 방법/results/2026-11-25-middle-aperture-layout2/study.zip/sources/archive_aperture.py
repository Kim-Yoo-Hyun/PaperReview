"""Bundle drawer measurements and losslessly record a second physical replay."""
import argparse
from collections import defaultdict
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


@contextmanager
def new_bundle(destination):
    if destination.exists():
        raise FileExistsError(destination)
    with tempfile.TemporaryDirectory(dir=destination.parent) as tmp:
        stage = Path(tmp)/'bundle'
        stage.mkdir()
        yield stage
        sums = [f'{sha(p.read_bytes())}  {p.name}\n' for p in sorted(stage.iterdir())]
        (stage/'SHA256SUMS').write_text(''.join(sums))
        stage.rename(destination)


def pack(run, proof_file, figure, metadata_file, destination):
    result, proof = read(run/'verification.json'), read(proof_file)
    assert result['paths']==proof['paths']==len(proof['runs'])
    assert proof['alternate_controls']==sum(r['policy_controls'] for r in proof['runs'])
    if 'standalone' in result:
        assert result['standalone']['paths']==proof['standalone']['paths']
    metadata = read(metadata_file)
    logs = defaultdict(list)
    files = {}
    for p in sorted(run.rglob('*')):
        if not p.is_file() or p==run/'verification.json':
            continue
        name = p.relative_to(run).as_posix()
        if p.parent.name=='logs' and not p.name.startswith('policy-'):
            logs[sha(p.read_bytes())].append(name)
        else:
            files[name] = p
    for h,names in logs.items():
        files['logs/simulator-'+h+'.log'] = run/names[0]
    metadata['path_log_groups_sha256'] = dict(logs)
    metadata['archive_script_sha256'] = sha(Path(__file__).read_bytes())
    files['sources/archive_aperture.py'] = Path(__file__)
    with new_bundle(destination) as stage:
        archive = stage/'study.zip'
        with ZipFile(archive,'x',compression=ZIP_DEFLATED,compresslevel=9) as z:
            for name,p in sorted(files.items()):
                z.write(p,name)
            z.writestr('environment.json',json.dumps(metadata,indent=2)+'\n')
        with ZipFile(archive) as z:
            assert z.testzip() is None and set(z.namelist())==set(files)|{'environment.json'}
            assert all(z.read(name)==p.read_bytes() for name,p in files.items())
            assert json.loads(z.read('environment.json'))==metadata
        shutil.copyfile(run/'verification.json',stage/'verification.json')
        shutil.copyfile(proof_file,stage/'physical_replay.json')
        shutil.copyfile(figure,stage/'middle_aperture.png')


def rerender_differences(first, second):
    changes = {}
    for a,b in zip(first,second,strict=True):
        assert dict(a,changed_rgb_ticks=b['changed_rgb_ticks'])==b, a['session']
        if a['changed_rgb_ticks']!=b['changed_rgb_ticks']:
            changes[a['session']] = b['changed_rgb_ticks']
    return changes


def seal(archive, repeat_file, destination):
    checksums = {n:h for h,n in (line.split('  ',1) for line in (archive/'SHA256SUMS').read_text().splitlines())}
    assert set(checksums)=={'study.zip','verification.json','physical_replay.json','middle_aperture.png'}
    assert all(sha((archive/n).read_bytes())==h for n,h in checksums.items())
    first,second = read(archive/'physical_replay.json'),read(repeat_file)
    repeat_digest = sha(json.dumps(second,sort_keys=True,separators=(',',':')).encode())
    metadata = dict(source_zip_sha256=checksums['study.zip'], repeat_report_digest=repeat_digest,
                    rerender_overrides=rerender_differences(first['runs'],second['runs']))
    second['runs'] = first['runs']
    if 'standalone' in first:
        direct = first['standalone']['runs']
        metadata['standalone_rerender_overrides'] = rerender_differences(direct,second['standalone']['runs'])
        second['standalone']['runs'] = direct
    assert first==second
    first['archive_repeat'] = metadata
    with new_bundle(destination) as stage:
        for name in ('study.zip','verification.json','middle_aperture.png'):
            shutil.copyfile(archive/name,stage/name)
        (stage/'physical_replay.json').write_text(json.dumps(first,indent=2)+'\n')


if __name__=='__main__':
    parser = argparse.ArgumentParser()
    stages = parser.add_subparsers(dest='stage',required=True)
    for name,fields in [('pack',('run','proof','figure','metadata','destination')),
                        ('seal',('archive','repeat','destination'))]:
        sub = stages.add_parser(name)
        for field in fields:
            sub.add_argument(field,type=Path)
    args = parser.parse_args()
    if args.stage=='pack':
        pack(args.run,args.proof,args.figure,args.metadata,args.destination)
    else:
        seal(args.archive,args.repeat,args.destination)
