"""Compare the native controls across two archived studies at matched seeds and initial observations."""
from collections import Counter
from contextlib import ExitStack
from pathlib import Path
from zipfile import ZipFile
import json
import sys

import numpy as np


def reader(stack,p):
    if (p/'study.zip').is_file():
        return stack.enter_context(ZipFile(p/'study.zip')).read
    return lambda n:(p/n).read_bytes()


def compare(past,current):
    with ExitStack() as stack:
        old,new=(reader(stack,p) for p in (past,current))
        runtime=[json.loads(r('runtime.json')) for r in (old,new)]
        stable=('image','gpu','checkpoint','policy_python','jax','simulator','commits')
        assert all(runtime[0][key]==runtime[1][key] for key in stable)
        source_diffs=[n for n,h in runtime[0]['sources'].items() if runtime[1]['sources'].get(n)!=h]
        entries=json.loads(new('sessions.json'))
        comparisons=Counter()
        delta,examples=[],{}
        first_controls=[]
        for name,e in entries.items():
            if e['mode']!='native-bottom':
                continue
            a,b=(json.loads(r('paths/'+name+'.json')) for r in (old,new))
            x,y=(json.loads(r(e['receipts']).splitlines()[0]) for r in (old,new))
            inputs=('prompt','proprioception','rgb_sha256','rng_before','rng_after')
            identical=all(x[k]==y[k] for k in inputs)
            physics=a['queries'][0]['physics']==b['queries'][0]['physics']
            dt=np.abs(np.subtract(a['queries'][0]['reply'],b['queries'][0]['reply']))
            comparisons.update(dict(pairs=1,identical_first_input_and_rng=int(identical),same_first_physics=int(physics),
                                    same_first_reply=int(x['actions_sha256']==y['actions_sha256']),same_first_five=int(not dt[:5].any())))
            delta.append(float(dt.max()))
            first_controls.append(float(dt[:5].max()))
            if e['arm'] not in examples:
                examples[e['arm']]=dict(session=name,first_control_old=a['rows'][0]['action'],first_control_new=b['rows'][0]['action'])
        stats=lambda a:dict(min=min(a),median=float(np.median(a)),max=max(a))
        return dict(pairs=dict(comparisons),same_runtime_fields=list(stable),changed_parent_sources=source_diffs,
            max_abs_component_first_reply=stats(delta),max_abs_component_executed_first_five=stats(first_controls),examples=examples)


if __name__=='__main__':
    print(json.dumps(compare(Path(sys.argv[1]),Path(sys.argv[2])),indent=2))
