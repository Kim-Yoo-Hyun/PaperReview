"""Measure world-frame gripper velocity at the exact 16 independently restored handoffs."""
import json
from pathlib import Path
import sys

import mujoco
import numpy as np

from atomic_control import capture_state
from drawer_gripper_position_starts import BASE, LAYOUT, MODES, branch, live_study
from drawer_location_sim import LocationCabinet
from drawer_width import tape_for
from middle_aperture_sim import environment, restore
from verify_atomic import read
from verify_stove_layouts import digest


def measure(out):
    settings = read(out/'clearance.json')['arrangements']
    starts = {}
    for arm,layout in LAYOUT.items():
        starts[arm] = {}
        for mode in MODES:
            env = environment(arm,layout=layout)
            try:
                scene = LocationCabinet(env)
                common = restore(env,scene,arm,out,donors_file=live_study(out,layout)['donors'])
                branch(env,scene,common,mode,BASE['lead'],corrections=settings[arm])
                tape = tape_for(out,arm,mode)
                signature = tape['first']['physics']
                assert digest(capture_state(env))==signature and scene.read()==tape['handoff']
                robot=env.robots[0]
                model,data=env.sim.model._model,env.sim.data._data
                linear,angular=(np.zeros((3,model.nv)) for _ in range(2))
                mujoco.mj_jacSite(model,data,linear,angular,robot.eef_site_id)
                velocity=linear@data.qvel
                rotation=angular@data.qvel
                vector=np.empty(6)
                mujoco.mj_objectVelocity(model,data,mujoco.mjtObj.mjOBJ_SITE,robot.eef_site_id,vector,0)
                np.testing.assert_allclose(vector,np.r_[rotation,velocity],rtol=0.,atol=1.e-12)
                assert data.qvel[robot._ref_joint_vel_indexes].tolist()==tape['handoff']['tool']['velocity']
                assert digest(capture_state(env))==signature
                starts[arm][mode]=dict(physics=signature,linear_world_mm_s=(1000*velocity).tolist(),
                    linear_speed_mm_s=float(1000*np.linalg.norm(velocity)),angular_world_rad_s=rotation.tolist(),
                    angular_speed_deg_s=float(np.degrees(np.linalg.norm(rotation))))
            finally:
                env.close()
    return starts


if __name__=='__main__':
    print(json.dumps(measure(Path(sys.argv[1])),indent=2))
