"""Recount camera-window quartets from gripper geometry, drawer regions and signed-off server receipts."""
from collections import Counter,defaultdict
from contextlib import ExitStack
from pathlib import Path
import json
import sys

import numpy as np

from geometry_receipts import raw_path, reader


def compare(directory,previous):
    with ExitStack() as stack:
        get,old=(reader(stack,p) for p in (directory,previous))
        entries=json.loads(get('sessions.json'))
        geos=json.loads(get('qualification.json'))['geometry']
        keys=json.loads(get('rng.json'))
        assert geos==json.loads(old('qualification.json'))['geometry'] and keys==json.loads(old('rng.json'))
        score=json.loads((directory/'verification.json').read_bytes())
        labels=('observation/image','observation/wrist_image')
        views={'self':(), 'external':labels[:1], 'wrist':labels[1:], 'both':labels}
        groups=defaultdict(dict)
        previous_controls=defaultdict(Counter)
        delivered=Counter()
        endpoints=defaultdict(lambda:defaultdict(Counter))
        first_actions={}
        historical_targets=defaultdict(dict)
        starts={}
        switch_actions={}
        changed_pixels=defaultdict(list)
        host_widths=[]
        for name,e in entries.items():
            layout,arm,mode,view=str(e['layout']),e['arm'],e['mode'],e['view']
            measured,prefix=raw_path(get,e,geos[layout],keys)
            assert all(measured[k]==score['paths_by_session'][name][k] for k in measured), name
            path=json.loads(get('paths/'+name+'.json'))
            wire=[json.loads(r) for r in get(e['receipts']).splitlines()]
            first_actions[name]=prefix
            switch_actions[name]=np.asarray(path['queries'][2]['reply'][:5])
            starts[name]=(wire[0]['rgb_sha256'],wire[0]['proprioception'],wire[0]['rng_before'],wire[0]['actions_sha256'],path['rows'][0]['action'])
            for i,(q,receipt) in enumerate(zip(path['queries'],wire,strict=True)):
                live=q['live']
                observed={cam for cam in labels if receipt['rgb_sha256'][cam]!=live[cam]}
                if i in (2,3): host_widths.append(-1000*q['render']['host_qpos'])
                active=i in (2,3) and (measured['contact_tick'] is None or measured['contact_tick']>i*5)
                planned=set(views[view]) if active else set()
                assert observed<=planned
                for cam in labels:
                    source=q['render']['narrow_rgb'] if cam in planned else live
                    assert receipt['rgb_sha256'][cam]==source[cam]
                for cam in planned:
                    changed_pixels[str(i)+'/'+cam].append(q['render']['changed_pixels'][cam])
                if observed:
                    delivered.update((view+'/'+cam for cam in observed))
            group=layout+'/'+mode
            index=(group,arm,e['key'],e['block'])
            groups[index][view]=measured
            for field in ('contact','at15','at30'):
                endpoints[group][view+'/'+field][measured[field]]+=1
            if view in ('self','both'):
                prior=dict(e,session=name.replace('.both-','.late-'),receipts=e['receipts'].replace('.both-','.late-'))
                historical,_=raw_path(old,prior,geos[layout],keys)
                historical_targets[index][view]=historical['contact']
                previous_controls[group+'/'+view].update({f:int(measured[f]==historical[f]) for f in ('contact','at15','at30')})
                previous_controls[group+'/'+view]['paths']+=1
        group_results=defaultdict(Counter)
        for (group,arm,key,block),data in groups.items():
            layout,mode=group.split('/')
            assert set(data)==set(views)
            contacts={v:r['contact'] for v,r in data.items()}
            own,both=contacts['self'],contacts['both']
            candidates=[v for v in ('external','wrist') if contacts[v]==both]
            category={(): 'neither_match',('external',):'external_only',('wrist',):'wrist_only',('external','wrist'):'both_match'}[tuple(candidates)] if own!=both else 'controls_agree'
            group_results[group][category]+=1
            ident='/'.join((layout,mode,arm,str(block),str(key)))
            assert score['quartets'][ident]['category']==category and score['quartets'][ident]['targets']==contacts
            prefix=[first_actions[f'{arm}-{mode}.{v}-b{block}-s{key}'] for v in views]
            if all(x==prefix[0] for x in prefix):
                group_results[group]['exact_first_ten_and_first_two_receipts']+=1
        switch_stats={}
        for group in group_results:
            deltas=defaultdict(list)
            for (g,arm,key,block),data in groups.items():
                if g!=group: continue
                layout,mode=g.split('/')
                detail=score['quartets']['/'.join((layout,mode,arm,str(block),str(key)))]
                if not (detail['matched_prefix'] and detail['same_switch_native'] and detail['same_switch_alternate']): continue
                cmds={v:switch_actions[f'{arm}-{mode}.{v}-b{block}-s{key}'] for v in views}
                for v in ('external','wrist','both'):
                    deltas[v].append(float(np.abs(cmds[v]-cmds['self']).max()))
            switch_stats[group]={v:dict(quartets=len(ds),changed=sum(x>0 for x in ds),median_max_abs=float(np.median(ds)),max=max(ds)) for v,ds in deltas.items()}
        historical_changes=defaultdict(Counter)
        for index,c in groups.items():
            h=historical_targets[index]
            before=h['self']!=h['both']
            after=c['self']['contact']!=c['both']['contact']
            historical_changes[index[0]][str(int(before))+'->'+str(int(after))]+=1
        twins=[(value,starts[n.replace('-b1-s','-b2-s')]) for n,value in starts.items() if '-b1-s' in n]
        reload_first=dict(pairs=len(twins),same_inputs=sum(a[:3]==b[:3] for a,b in twins),same_output=sum(a[3]==b[3] for a,b in twins),
            max_first_action_component_delta=max(abs(u-v) for a,b in twins for u,v in zip(a[4],b[4])))
        for group,counts in group_results.items():
            main=score['groups'][group]
            assert all(counts[k]==main['primary'][k] for k in ('external_only','wrist_only','both_match','neither_match'))
            for name,vals in endpoints[group].items():
                view,field=name.split('/')
                assert vals==main['outcomes'][view][field]
            for v in ('self','both'):
                c=previous_controls[group+'/'+v]
                assert all(score['parent_controls'][group][v][k]==c[k] for k in ('contact','at15','at30'))
        return dict(paths=len(entries),receipts=108*len(entries),quartets=len(groups),
                    host_width_mm_at_late_queries=[min(host_widths),max(host_widths)],matched_switch_first_five=switch_stats,changed_pixels={k:dict(n=len(v),min=min(v),median=float(np.median(v)),max=max(v)) for k,v in changed_pixels.items()},
                    historical_change_pairs=dict(historical_changes),model_reload_first_query=reload_first,changed_frames=dict(delivered),counts=dict(group_results),parent_controls=dict(previous_controls))


if __name__=='__main__':
    print(json.dumps(compare(Path(sys.argv[1]),Path(sys.argv[2])),indent=2))
