"""Show the two camera images and their exact changed-pixel masks at one recorded late query."""
from pathlib import Path
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image


def plot(frames,output):
    fig,axes=plt.subplots(2,3,figsize=(7.8,5.25))
    fig.subplots_adjust(left=.11,right=.98,top=.83,bottom=.035,wspace=.04,hspace=.04)
    fig.suptitle('The same bottom drawer seen by two cameras',fontsize=16,y=.989)
    fig.text(.54,.92,'Layout 2 · original gripper start · seed 0 · first model load · 0.5 s',ha='center',fontsize=10)
    for col,label in enumerate(('Actual opening ≈160 mm','Rendered opening 76 mm','Pixels that changed')):
        axes[0,col].set_title(label,fontsize=10,pad=5)
    for i,cam in enumerate(('external','wrist')):
        prefix='2-native-bottom-'+cam
        wide,narrow=(np.array(Image.open(frames/(prefix+'-'+w+'.png')).convert('RGB')) for w in ('wide','narrow'))
        mask=np.any(wide!=narrow,axis=2)
        for j,im in enumerate((wide,narrow,mask)):
            axes[i,j].imshow(im,interpolation='nearest',cmap='gray',vmin=0,vmax=1)
            axes[i,j].set_xticks([]);axes[i,j].set_yticks([])
            axes[i,j].spines[:].set_visible(False)
        axes[i,0].set_ylabel('External' if i==0 else 'Wrist',fontsize=12)
    fig.savefig(output,dpi=160,bbox_inches='tight',facecolor='white')
    plt.close(fig)


if __name__=='__main__':
    plot(Path(sys.argv[1]),Path(sys.argv[2]))
