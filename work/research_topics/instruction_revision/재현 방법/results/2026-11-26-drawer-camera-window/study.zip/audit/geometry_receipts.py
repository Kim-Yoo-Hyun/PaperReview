"""Independently rebuild contact, occupancy and paired contrasts from a directory or study.zip."""
from collections import Counter, defaultdict
from contextlib import ExitStack
from hashlib import sha256
from pathlib import Path
import json
import sys
from zipfile import ZipFile

import numpy as np


def reader(stack, directory):
    if (directory/'study.zip').exists():
        return stack.enter_context(ZipFile(directory/'study.zip')).read
    return lambda n: (directory/n).read_bytes()


def raw_path(get, entry, geo, keys):
    n = entry['session']
    path = json.loads(get('paths/'+n+'.json'))
    rows = path['rows']
    assert len(rows)==540 and entry['lead']==60
    labels = {i:name for name in ('top','middle','bottom','bowl') for i in geo[name]}
    fingers = set(geo['fingers'])
    events = [sorted({labels[other] for finger,other in r['gripper_pairs'] if finger in fingers and other in labels}) for r in rows]
    tick = next((i for i,contacts in enumerate(events,1) if contacts),None)
    contact = '+'.join(events[tick-1]) if tick else 'none'
    xyz = np.array([r['bowl_xyz'] for r in rows])
    inside = {}
    for level, center, extent, flag in [('top','target_xyz','site_extent_world','bowl_in'),
            ('middle','middle_xyz','middle_extent','middle_in'),('bottom','bottom_xyz','bottom_extent','bottom_in')]:
        d = xyz - np.array([r[center] for r in rows])
        bound = np.array(geo[extent])
        lo = -bound.copy()
        lo[2] -= geo['lower_z_allowance_m']
        inside[level] = ((lo < d) & (d < bound)).all(axis=1)
        assert np.array_equal(inside[level],[r[flag] for r in rows])
    def destination(i):
        return '+'.join(k for k in inside if inside[k][i-1]) or 'none'
    first_place = next((i for i in range(1,541) if destination(i)!='none'),None)
    result = dict(contact=contact, contact_tick=tick, place_tick=first_place,
                  first_destination=destination(first_place) if first_place else 'none',
                  at15=destination(240), at30=destination(540), final_physics=path['final_physics'])
    receipts = [json.loads(row) for row in get(entry['receipts']).splitlines()]
    sequence = keys[str(entry['key'])]
    result['exchanged'] = []
    assert len(receipts)==len(path['queries'])==108
    for i,(q,r) in enumerate(zip(path['queries'],receipts,strict=True)):
        assert q['tick']==60+5*i and r['proprioception']==q['state'] and r['prompt']==entry['source']
        assert sequence[32+i:34+i]==[r['rng_before'],r['rng_after']]
        assert sha256(np.array(q['reply'],dtype='<f8').tobytes()).hexdigest()==r['actions_sha256']
        assert q['reply'][:5]==[v['action'] for v in rows[5*i:5*i+5]]
        if i<4:
            assert q['render']['host_after']==q['physics'] and q['render']['self_rgb']==q['live']
        if r['rgb_sha256']!=q['live']:
            assert i<4 and r['rgb_sha256']==q['render']['sent'] and q['render']['exchange']
            result['exchanged'].append(i)
        elif i<4:
            assert not q['render']['exchange']
    prefix = dict(actions=[r['action'] for r in rows[:10]], inputs=receipts[:2], physics=[q['physics'] for q in path['queries'][:2]])
    return result,prefix


def audit(directory, previous):
    with ExitStack() as stack:
        get = reader(stack,directory)
        get_old = reader(stack,previous)
        entries = json.loads(get('sessions.json'))
        geometry = json.loads(get('qualification.json'))['geometry']
        old_geo = json.loads(get_old('qualification.json'))['geometry']
        keys = json.loads(get('rng.json'))
        assert keys==json.loads(get_old('rng.json'))
        score = json.loads((directory/'verification.json').read_bytes())
        outcomes, prefixes, historic = {}, {}, defaultdict(Counter)
        checks = 0
        for name,entry in entries.items():
            layout, arm, seed, block = str(entry['layout']),entry['arm'],entry['key'],entry['block']
            pos,view = entry['mode'].split('-')[0], entry['view']
            index = layout,arm,seed,block,pos,view
            curr, prefix = raw_path(get,entry,geometry[layout],keys)
            assert all(curr[k]==score['paths_by_session'][name][k] for k in curr), name
            outcomes[index], prefixes[index] = curr,prefix
            checks+=108
            if pos=='native':
                old,_ = raw_path(get_old,entry,old_geo[layout],keys)
                historic[layout].update({k:int(curr[k]==old[k]) for k in ('contact','contact_tick','at15','at30','final_physics')})
                historic[layout]['pairs']+=1
        layouts = {}
        for layout in ('2','3'):
            arms = sorted({k[1] for k in outcomes if k[0]==layout})
            changes = Counter()
            sensitivity = Counter()
            unique = defaultdict(list)
            exceptions = []
            for arm in arms:
                for seed in range(8):
                    for block in (1,2):
                        valid = True
                        flags = []
                        for pos in ('native','crossed'):
                            base = layout,arm,seed,block,pos
                            own,late = (prefixes[base+(v,)] for v in ('self','late'))
                            flags.append(int(outcomes[base+('self',)]['contact']!=outcomes[base+('late',)]['contact']))
                            if own['actions']!=late['actions'] or own['inputs']!=late['inputs'] or own['physics']!=late['physics']:
                                valid=False
                                a,b = np.array(own['actions']),np.array(late['actions'])
                                exceptions.append(dict(arm=arm,seed=seed,block=block,position=pos,max_action_delta=float(np.abs(a-b).max()),
                                    same_physics=(own['physics']==late['physics']),same_sent=[x['rgb_sha256']==y['rgb_sha256'] for x,y in zip(own['inputs'],late['inputs'])]))
                        category = ('both' if flags[1] else 'native_only') if flags[0] else ('crossed_only' if flags[1] else 'neither')
                        changes[category]+=1
                        unique[arm,seed].append(category)
                        if valid:
                            sensitivity[category]+=1
            assert all(changes[k]==score['layouts'][layout]['late'][k] for k in ('native_only','crossed_only','both','neither'))
            layouts[layout] = dict(paired=dict(changes),clean_pre_window_pairs=dict(sensitivity),prefix_exceptions=exceptions,
                posture_seed_repeated_categories=dict(Counter(c[0] if len(set(c))==1 else 'mixed' for c in unique.values())),
                previous_native_agreement=dict(historic[layout]))
        return dict(paths=len(outcomes),historical_native_paths=sum(x['pairs'] for x in historic.values()),
            policy_receipts=checks,identified_exchanges=sum(len(v['exchanged']) for v in outcomes.values()),layouts=layouts)


if __name__=='__main__':
    print(json.dumps(audit(Path(sys.argv[1]),Path(sys.argv[2])),indent=2))
