"""Rerender both candidate images before routing, at the two late queries on seed zero."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys

import numpy as np
from PIL import Image

from atomic_control import capture_state,digest
from drawer_camera_window import BASE, CAMERAS, CHANNELS, DESIGN, HOSTS, LAYOUT, STUDIES, TASK, branch, live_study
from drawer_location_sim import LocationCabinet
from drawer_sim import observe,state_hash
from drawer_view_render import DrawerViews
from drawer_width import tape_for
from middle_aperture_sim import environment,restore
from verify_atomic import read


def replay_pixel_pair(out,folder,e):
    arm,mode=e['arm'],e['mode']
    study=live_study(out,e['layout'])
    env=environment(arm,layout=study['layout'])
    try:
        scene=LocationCabinet(env)
        common=restore(env,scene,arm,out,donors_file=study['donors'])
        branch(env,scene,common,mode,BASE['lead'],corrections=read(out/'clearance.json')['arrangements'][arm])
        host=tape_for(out,arm,mode)
        assert scene.read()==host['handoff'] and state_hash(capture_state(env))==host['first']['physics']
        renderer=DrawerViews(env,'bottom')
        narrow=scene.slides['bottom']['closed']-DESIGN['camera_width_m']
        path=read(out/'paths'/(e['session']+'.json'))
        wire=[json.loads(row) for row in (out/e['receipts']).read_bytes().splitlines()]
        results=[]
        for i in range(4):
            q=path['queries'][i]
            query,sample=observe(env,None,False,TASK['prompt'])
            assert q['physics']==sample['physics'] and q['state']==sample['state']==wire[i]['proprioception']
            if i in (2,3):
                # Native and alternate are rendered regardless of which channel was assigned.
                mixed_ok=False
                for attempt in range(1,9):
                    if attempt>1:
                        query,sample=observe(env,None,False,TASK['prompt'])
                    assert sample['physics']==q['physics'] and sample['state']==q['state']
                    alternate_native,r=renderer.images(query,sample,narrow)
                    expected=q['render']
                    contacted=any(any(other in set().union(*(scene.geometry[level] for level in ('top','middle','bottom','bowl')))
                                       for _,other in row['gripper_pairs']) for row in path['rows'][:i*5])
                    channels=CHANNELS[e['view']] if not contacted else []
                    assert channels==expected['selected']
                    mixed={c:(alternate_native if c in channels else query)[c] for c in CAMERAS}
                    candidate_match=not channels or r['sent']==expected['narrow_rgb']
                    mixed_ok=all(digest(mixed[c])==wire[i]['rgb_sha256'][c] for c in CAMERAS)
                    exact=mixed_ok and candidate_match and r['self_rgb']==q['live']
                    if exact: break
                assert state_hash(capture_state(env))==q['physics']
                files={}
                if i==2 and e['view']=='both' and arm==STUDIES[e['layout']]['arms'][0]:
                    for key,images in [('wide',query),('narrow',alternate_native)]:
                        files[key]={}
                        for channel,cam in zip(('external','wrist'),CAMERAS,strict=True):
                            filename=f"{e['layout']}-{mode}-{channel}-{key}.png"
                            Image.fromarray(images[cam]).save(folder/filename)
                            files[key][cam]=filename
                results.append(dict(index=i,physics=q['physics'],selected=channels,attempts=attempt,exact=exact,
                    delivered_matches_wire=mixed_ok,native=r['self_rgb'],narrow=r['sent'],route={c:digest(mixed[c]) for c in CAMERAS},
                    changed_pixels=r['changed_pixels'],example_frames=files))
            if i<3:
                for row in path['rows'][5*i:5*i+5]:
                    env.step(row['action'])
                    assert scene.policy_row()=={k:v for k,v in row.items() if k!='action'}
        return results
    finally:
        env.close()


if __name__=='__main__':
    out,folder=(Path(x) for x in sys.argv[1:3])
    folder.mkdir(exist_ok=True,parents=True)
    entries=read(out/'sessions.json')
    if len(sys.argv)>3:
        print(json.dumps(replay_pixel_pair(out,folder,entries[sys.argv[3]])))
    else:
        selected=[n for n,e in entries.items() if e['key']==0 and e['block']==1]
        assert len(selected)==32
        def one(n):
            text=subprocess.check_output([sys.executable,__file__,str(out),str(folder),n],text=True)
            return json.loads(text.strip().splitlines()[-1])
        with ThreadPoolExecutor(max_workers=2) as pool:
            results=dict(zip(selected,pool.map(one,selected),strict=True))
        (folder/'samples.json').write_text(json.dumps(results,indent=2)+'\n')
        rows=[r for result in results.values() for r in result]
        print(len(rows),'physical queries,',sum(r['exact'] for r in rows),'exact raw pixel hash pairs;',sum(r['delivered_matches_wire'] for r in rows),'matched on the wire')
